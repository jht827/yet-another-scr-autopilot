from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Screen regions
REGION_SPEED = (2144, 1310, 2206, 1341)
REGION_MILES = (180, 1378, 222, 1393)
REGION_DOOR_STATUS = (1223, 13, 1335, 31)
REGION_SELECT_DESTINATION = (676, 57, 854, 80)

# Unit conversion
MPH_TO_MILES_PER_SEC = 1 / 3600

# Timing and input
COOLDOWN = 3.0
TQ_PRESS_INTERVAL = 1.0
W_PRESS_COOLDOWN = 35
STOPPED_W_PRESS_DELAY = 30
STOPPED_W_PRESS_DURATION = 2.5
DOOR_KEY_PRESS_DURATION = 2.0

# Curve settings
DECEL_CURVE_PATH = BASE_DIR / "class_357_decel.csv.csv"
CURVE_SMOOTHING_WINDOW = 5

# Additive distance adjustment (miles) to compensate for short-stop bias
DISTANCE_ADJUST_MI = 0.0

# Main loop interval (seconds)
LOOP_INTERVAL = 0.2

# Select Destination automation
SELECT_DESTINATION_INTERVAL = 60

# Debug logging
DEBUG_OCR = True
