from scr_autopilot.hud_readout import main


if __name__ == "__main__":
    main()
