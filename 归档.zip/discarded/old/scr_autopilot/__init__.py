"""Core package for the SCR autopilot project."""
