Template directories for HUD digit matching.

Place digit PNGs (0.png-9.png) into the subfolders:
- templates/speed
- templates/limit
- templates/distance

These folders are used by `hud_readout.py` by default.
